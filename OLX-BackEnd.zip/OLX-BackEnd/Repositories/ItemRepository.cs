﻿using Microsoft.EntityFrameworkCore;
using OLXShopping.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;

namespace OLXShopping.Repositories
{
    public class ItemRepository : IItemRepository
    {
        private readonly OLXAppContext _context;

        public ItemRepository(OLXAppContext context)
        {
            _context = context;
        }

        public async Task<Item> GetByIdAsync(string id)
        {
            try
            {
                return await _context.Items.FindAsync(id);
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw new Exception("An error occurred while retrieving the item by ID.", ex);
            }
        }

        public async Task<IEnumerable<Item>> GetByNameAsync(string name)
        {
            return await _context.Items
                                 .Where(mi => mi.Name == name)
                                 .ToListAsync();
        }


        public async Task<IEnumerable<Item>> GetAllAsync()
        {
            try
            {
                return await _context.Items.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw new Exception("An error occurred while retrieving all items.", ex);
            }
        }

        public async Task AddAsync(Item item)
        {
            try
            {
                //await _context.Categories.AddAsync(category);
                await _context.Items.AddAsync(item);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw new Exception("An error occurred while adding the item.", ex);
            }
        }

        public async Task UpdateAsync(Item item)
        {
            try
            {
                _context.Items.Update(item);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw new Exception("An error occurred while updating the item.", ex);
            }
        }

        public async Task DeleteAsync(string id)
        {
            try
            {
                var item = await _context.Items.FindAsync(id);
                if (item != null)
                {
                    _context.Items.Remove(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw new Exception("An error occurred while deleting the item.", ex);
            }
        }


        public async Task<IEnumerable<Item>> GetItemsByFilterAsync(decimal? minPrice, decimal? maxPrice, string? categoryName, string? location, string? itemName)
        {
            try
            {
                var query = _context.Items
                    .Where(i => (!minPrice.HasValue || i.Price >= minPrice.Value) &&
                                (!maxPrice.HasValue || i.Price <= maxPrice.Value) &&
                                (string.IsNullOrEmpty(categoryName) || i.Category.CategoryName == categoryName) &&
                                (string.IsNullOrEmpty(location) || i.Location == location) &&
                                (string.IsNullOrEmpty(itemName) || i.Name.Contains(itemName)))
                    .Include(i => i.Category);

                return await query.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw new Exception("An error occurred while retrieving items by filter.", ex);
            }
        }
        public async Task<List<Item>> GetItemsByUserIdAsync(string userId)
        {
            return await _context.Items
                .Where(i => i.SellerId == userId)
                .ToListAsync();
        }

    }
}
