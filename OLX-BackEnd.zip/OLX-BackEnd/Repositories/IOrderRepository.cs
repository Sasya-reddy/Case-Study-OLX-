﻿using OLXShopping.Entities;

namespace OLXShopping.Repositories
{
    public interface IOrderRepository
    {
        Task<List<Order>> GetAllAsync();
        Task<Order> GetByIdAsync(Guid orderId);
        Task AddAsync(Order order);
        Task UpdateAsync(Order order);
        Task DeleteAsync(Guid orderId);
        Task<IEnumerable<Order>> GetOrdersByDateRange(DateTime startDate, DateTime endDate);

        Task<int> GetOrdersSoldByUserIdAsync(string userId);
        Task<List<Order>> GetOrdersBoughtByUserIdAsync(string userId);

    }
}
