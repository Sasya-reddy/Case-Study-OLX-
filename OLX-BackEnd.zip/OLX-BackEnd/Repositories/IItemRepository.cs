﻿using OLXShopping.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OLXShopping.Repositories
{
    public interface IItemRepository
    {
        Task<Item> GetByIdAsync(string id);
        Task<IEnumerable<Item>>GetByNameAsync(string name);

        Task<IEnumerable<Item>> GetAllAsync();
        Task AddAsync(Item item);
        Task UpdateAsync(Item item);
        Task DeleteAsync(string id);

        Task<List<Item>> GetItemsByUserIdAsync(string userId);


        // Updated method to filter items by price range, category name, location, and item name
        Task<IEnumerable<Item>> GetItemsByFilterAsync(decimal? minPrice, decimal? maxPrice, string? categoryName, string? location, string? itemName);
    }
}
