﻿using OLXShopping.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OLXShopping.Repositories
{
    public interface ITransactionRepository
    {
        Task AddAsync(Transaction transaction);
        Task<Transaction> GetByIdAsync(Guid transactionId);
        Task<List<Transaction>> GetAllAsync();
        Task UpdateAsync(Transaction transaction);
        Task DeleteAsync(Guid transactionId);
        Task<List<Transaction>> GetByUserIdAsync(string userId); // New method
    }
}
