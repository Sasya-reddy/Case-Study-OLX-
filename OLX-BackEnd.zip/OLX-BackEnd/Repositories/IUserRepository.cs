﻿using OLXShopping.Entities;

namespace OLXShopping.Repositories
{
    public interface IUserRepository
    {
        void Register(User user);
        User ValidUser(string email, string password);
        List<User> GetAllUsers();
        void Delete(string UserId);
        void Update(User user);


    }
}
