﻿using OLXShopping.Entities;

namespace OLXShopping.Repositories
{
    public interface ICategoryRepository
    {
        Task<Category> GetByIdAsync(string categoryId);
        Task<List<Category>> GetAllAsync();
        Task AddAsync(Category category);
        Task UpdateAsync(Category category);
        Task DeleteAsync(string categoryId);
    }
}

