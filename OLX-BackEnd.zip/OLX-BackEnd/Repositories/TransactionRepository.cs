﻿using Microsoft.EntityFrameworkCore;
using OLXShopping.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OLXShopping.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly OLXAppContext _context;
        private readonly IConfiguration _configuration;
        public TransactionRepository(OLXAppContext context, IConfiguration configuration)
        {
            _context = context;
            configuration = _configuration;
            
        }

        public async Task AddAsync(Transaction transaction)
        {
            try
            {
                await _context.Transactions.AddAsync(transaction);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while adding the transaction.", ex);
            }
        }

        public async Task DeleteAsync(Guid transactionId)
        {
            try
            {
                var transaction = await _context.Transactions.FindAsync(transactionId);
                if (transaction != null)
                {
                    _context.Transactions.Remove(transaction);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while deleting the transaction.", ex);
            }
        }

        public async Task<List<Transaction>> GetAllAsync()
        {
            try
            {
                return await _context.Transactions.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while fetching all transactions.", ex);
            }
        }

        public async Task<Transaction> GetByIdAsync(Guid transactionId)
        {
            try
            {
                return await _context.Transactions.FindAsync(transactionId);
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while fetching the transaction by ID.", ex);
            }
        }

        public async Task UpdateAsync(Transaction transaction)
        {
            try
            {
                _context.Transactions.Update(transaction);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while updating the transaction.", ex);
            }
        }

        public async Task<List<Transaction>> GetByUserIdAsync(string userId)
        {
            try
            {
                return await _context.Transactions
                    .Where(t => t.UserId == userId)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while fetching transactions by user ID.", ex);
            }
        }
    }
}
