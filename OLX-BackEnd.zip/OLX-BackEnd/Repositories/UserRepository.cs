﻿using Microsoft.EntityFrameworkCore;
using OLXShopping.Entities;

namespace OLXShopping.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly OLXAppContext _context;
        private readonly IConfiguration _configuration;

        public UserRepository(OLXAppContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public List<User> GetAllUsers()
        {
            try
            {
                return _context.Users.ToList();
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                throw new Exception("An error occurred while fetching all users.", ex);
            }
        }

        public void Register(User user)
        {
            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while registering the user.", ex);
            }
        }

        public User ValidUser(string email, string password)
        {
            try
            {
                return _context.Users.SingleOrDefault(a => a.Email == email && a.Password == password);
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while validating the user.", ex);
            }
        }

        public void Update(User user)
        {
            try
            {
                _context.Users.Update(user);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while updating the user.", ex);
            }
        }

        public void Delete(string userId)
        {
            try
            {
                var user = _context.Users.Find(userId);
                if (user != null)
                {
                    _context.Users.Remove(user);
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while deleting the user.", ex);
            }
        }
    }
}
