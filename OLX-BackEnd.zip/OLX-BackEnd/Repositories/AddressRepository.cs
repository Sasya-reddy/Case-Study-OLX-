﻿using Microsoft.EntityFrameworkCore;
using OLXShopping.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OLXShopping.Repositories
{
    public class AddressRepository : IAddressRepository
    {
        private readonly OLXAppContext _Context;
        private readonly IConfiguration _configuration;

        public AddressRepository(OLXAppContext context, IConfiguration configuration)
        {
            _Context = context;
            _configuration = configuration;
        }

        public async Task AddAsync(Address address)
        {
            try
            {
                await _Context.AddAsync(address);
                await _Context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("An error occurred while adding the address.", ex);
            }
        }
        public async Task<Address> GetByBuyerIdAsync(string buyerId)
        {
            try
            {
                return await _Context.Address.FirstOrDefaultAsync(a => a.BuyerId == buyerId);
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while retrieving the address by BuyerId.", ex);
            }
        }


        public async Task DeleteAsync(string addressId)
        {
            try
            {
                var address = await _Context.Address.FindAsync(addressId);
                if (address != null)
                {
                    _Context.Address.Remove(address);
                    await _Context.SaveChangesAsync();
                }
                else
                {
                    throw new Exception("Address not found.");
                }
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("An error occurred while deleting the address.", ex);
            }
        }

        public async Task<List<Address>> GetAllAsync()
        {
            try
            {
                return await _Context.Address.ToListAsync();
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("An error occurred while retrieving addresses.", ex);
            }
        }

        public async Task<Address> GetByIdAsync(string addressId)
        {
            try
            {
                return await _Context.Address.FindAsync(addressId);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("An error occurred while retrieving the address.", ex);
            }
        }

        public async Task UpdateAsync(Address address)
        {
            try
            {
                _Context.Address.Update(address);
                await _Context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("An error occurred while updating the address.", ex);
            }
        }
    }
}