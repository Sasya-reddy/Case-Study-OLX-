﻿using Microsoft.EntityFrameworkCore;
using OLXShopping.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OLXShopping.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly OLXAppContext _context;
        private readonly IConfiguration _configuration;

        public OrderRepository(OLXAppContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task AddAsync(Order order)
        {
            try
            {
                await _context.Orders.AddAsync(order);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while adding the order.", ex);
            }
        }

        public async Task DeleteAsync(Guid orderId)
        {
            try
            {
                var order = await _context.Orders.FindAsync(orderId);
                if (order != null)
                {
                    _context.Orders.Remove(order);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while deleting the order.", ex);
            }
        }

        public async Task<List<Order>> GetAllAsync()
        {
            try
            {
                return await _context.Orders.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while retrieving all orders.", ex);
            }
        }

        public async Task<Order> GetByIdAsync(Guid orderId)
        {
            try
            {
                return await _context.Orders.FindAsync(orderId);
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while retrieving the order by ID.", ex);
            }
        }

        public async Task UpdateAsync(Order order)
        {
            try
            {
                _context.Orders.Update(order);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while updating the order.", ex);
            }
        }

        //public async Task<List<Order>> GetOrdersBoughtByUserIdAsync(string userId)
        //{
        //    try
        //    {
        //        return await _context.Orders
        //            .Include(o => o.Item) // Include related items in the order
        //            .Where(o => o.BuyerId == userId) // Filter by the buyer's ID
        //            .ToListAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the exception
        //        throw new Exception("An error occurred while retrieving the orders bought by the user.", ex);
        //    }
        //}


        public async Task<List<Order>> GetOrdersBoughtByUserIdAsync(string userId)
        {
            try
            {
                // Retrieve orders including related items for the specified user
                return await _context.Orders
                    .Where(o => o.BuyerId == userId)
                    .Include(o => o.Item)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while retrieving the orders bought by the user.", ex);
            }
        }

        public async Task<int> GetOrdersSoldByUserIdAsync(string userId)
        {
            try
            {
                return await _context.Orders.CountAsync(o => o.SellerId == userId);
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while retrieving the count of orders sold by the user.", ex);
            }
        }
        public async Task<IEnumerable<Order>> GetOrdersByDateRange(DateTime startDate, DateTime endDate)
        {
            try 
            {
                return await _context.Orders
                                 .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)

                                 .ToListAsync();

            }
            //return await _context.Orders
                                 //.Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                                
                                 //.ToListAsync()
            catch (Exception ex)
            {
                throw new Exception("An error occured while retieving Date and time.", ex);
            }
        }
    }
}
