﻿using Microsoft.EntityFrameworkCore;
using OLXShopping.Entities;

namespace OLXShopping.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly OLXAppContext _context;
        private readonly IConfiguration _configuration;

       
        public CategoryRepository(OLXAppContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task AddAsync(Category category)
        {
            try
            {
                await _context.Categories.AddAsync(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                throw new Exception("An error occurred while adding the category.", ex);
            }
        }

        public async Task DeleteAsync(string categoryId)
        {
            try
            {
                var category = await _context.Categories.FindAsync(categoryId);
                if (category != null)
                {
                    _context.Categories.Remove(category);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while deleting the category.", ex);
            }
        }

        public async Task<List<Category>> GetAllAsync()
        {
            try
            {
                return await _context.Categories.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while fetching all categories.", ex);
            }
        }

        public async Task<Category> GetByIdAsync(string categoryId)
        {
            try
            {
                return await _context.Categories.FindAsync(categoryId);
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while fetching the category by ID.", ex);
            }
        }

        public async Task UpdateAsync(Category category)
        {
            try
            {
                _context.Categories.Update(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("An error occurred while updating the category.", ex);
            }
        }
    }
}
