﻿using OLXShopping.Entities;

namespace OLXShopping.Repositories
{
    public interface IAddressRepository
    {
        Task<Address> GetByIdAsync(string addressId);
        Task<List<Address>> GetAllAsync();
        Task<Address> GetByBuyerIdAsync(string buyerId);
        Task AddAsync(Address address);
        Task UpdateAsync(Address address);
        Task DeleteAsync(string addressId);
    }
}
