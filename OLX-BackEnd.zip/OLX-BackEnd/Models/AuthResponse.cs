﻿namespace OLXShopping.Models
{
    public class AuthResponse
    {
        public string UserId { get; set; }
        public string Role {  get; set; }
        public string Token { get; set; }
    }
}
