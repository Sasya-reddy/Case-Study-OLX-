﻿namespace OLXShopping.Models
{
    public class Login
    {
        public String Email {  get; set; }
        public String Password { get; set; }
    }
}
