﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OLXShopping.Entities;
using OLXShopping.Repositories;
using System;
using System.Threading.Tasks;

namespace OLXShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;
        private readonly IConfiguration _configuration;

        public ItemController(IItemRepository itemRepository, IConfiguration configuration)
        {
            _itemRepository = itemRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetByIdAsync(string id)
        {
            try
            {
                var item = await _itemRepository.GetByIdAsync(id);
                if (item == null)
                {
                    return NotFound($"Item with ID {id} not found.");
                }
                return Ok(item);
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw;
            }
        }
        [HttpGet, Route("GetByName/{name}")]
        public async Task<IActionResult> GetByNameAsync(string name)
        {
            try
            {
                var item = await _itemRepository.GetByNameAsync(name);
                if (item == null)
                {
                    return NotFound($"Item with ID {name} not found.");
                }
                return Ok(item);
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                throw;
            }
        }

        [HttpGet, Route("GetAllItems")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var items = await _itemRepository.GetAllAsync();
                return Ok(items);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost, Route("AddItems")]
        public async Task<IActionResult> AddAsync([FromBody] Item item)
        {
            try
            {
               
                    //user.UserId = Guid.NewGuid().ToString();
                    item.ItemId = "I" + new Random().Next(1000, 9999);// Or use your preferred ID generation logic
                
               
                await _itemRepository.AddAsync(item);
                return Ok(item);
            }
            catch (Exception ex)
            {
               
                throw;
                //return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while adding the item: {ex.Message}");
            }
        }

        [HttpPut, Route("UpdateItem")]
        public async Task<IActionResult> UpdateAsync( [FromBody] Item item)
        {
            try
            {
                await _itemRepository.UpdateAsync(item);
                return Ok(item);
            }
            catch (Exception ex)
            {
                // Log the exception if necessary

                throw;
            }
        }

        [HttpDelete, Route("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteAsync(string id)
        {
            try
            {
                await _itemRepository.DeleteAsync(id);
                return Ok(id); // No content indicates successful deletion
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        [HttpGet, Route("GetItemsByUserId/{userId}")]
        public async Task<IActionResult> GetItemsByUserIdAsync(string userId)
        {
            try
            {
                var items = await _itemRepository.GetItemsByUserIdAsync(userId);
                if (items == null || items.Count == 0)
                {
                    return NotFound($"No items found for user with ID {userId}.");
                }
                return Ok(items);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        // New endpoint to get items by filter
        [HttpGet, Route("GetItemsByFilter")]
        public async Task<IActionResult> GetItemsByFilterAsync([FromQuery] decimal? minPrice, [FromQuery] decimal? maxPrice, [FromQuery] string? categoryName, [FromQuery] string? location, [FromQuery] string? itemName)
        {
            try
            {
                var items = await _itemRepository.GetItemsByFilterAsync(minPrice, maxPrice, categoryName, location, itemName);
                return Ok(items);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
