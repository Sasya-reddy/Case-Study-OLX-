﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OLXShopping.Repositories;
using OLXShopping.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OLXShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepository _transactionRepository;
        private readonly IConfiguration _configuration;

        public TransactionController(ITransactionRepository transactionRepository, IConfiguration configuration)
        {
            _transactionRepository = transactionRepository;
            _configuration = configuration;
        }

        // GET: api/Transaction/GetAllTransactions
        [HttpGet, Route("GetAllTransactions")]
        public async Task<IActionResult> GetAllTransactions()
        {
            try
            {
                var transactions = await _transactionRepository.GetAllAsync();
                return Ok(transactions);
            }
            catch (Exception ex)
            {
                // Log the exception (you can use a logging framework)
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving transactions: {ex.Message}");
            }
        }

        // GET: api/Transaction/GetById/{id}
        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetTransactionById(Guid id)
        {
            try
            {
                var transaction = await _transactionRepository.GetByIdAsync(id);
                if (transaction == null)
                {
                    return NotFound();
                }
                return Ok(transaction);
            }
            catch (Exception ex)
            {
                // Log the exception (you can use a logging framework)
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the transaction: {ex.Message}");
            }
        }

        // POST: api/Transaction/AddTransaction
        [HttpPost, Route("AddTransaction")]
        public async Task<IActionResult> AddTransaction([FromBody] Transaction transaction)
        {
            try
            {
                transaction.TransactionId = Guid.NewGuid();
                await _transactionRepository.AddAsync(transaction);
                return Ok(transaction);
            }
            catch (Exception ex)
            {
                // Log the exception (you can use a logging framework)
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while adding the transaction: {ex.Message}");
            }
        }

        // PUT: api/Transaction/UpdateTransaction/{id}
        [HttpPut("UpdateTransaction/{id}")]
        public async Task<IActionResult> UpdateTransaction(Guid id, [FromBody] Transaction transaction)
        {
            try
            {
                // Ensure the transaction ID is set correctly
                transaction.TransactionId = id;
                await _transactionRepository.UpdateAsync(transaction);
                return Ok(transaction);
            }
            catch (Exception ex)
            {
                // Log the exception (you can use a logging framework)
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while updating the transaction: {ex.Message}");
            }
        }

        // DELETE: api/Transaction/DeleteTransaction/{id}
        [HttpDelete, Route("DeleteTransaction/{id}")]
        public async Task<IActionResult> DeleteTransaction(Guid id)
        {
            try
            {
                await _transactionRepository.DeleteAsync(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                // Log the exception (you can use a logging framework)
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the transaction: {ex.Message}");
            }
        }

        // GET: api/Transaction/GetTransactionsByUserId/{userId}
        [HttpGet("GetTransactionsByUserId/{userId}")]
        public async Task<IActionResult> GetTransactionsByUserId(string userId)
        {
            try
            {
                var transactions = await _transactionRepository.GetByUserIdAsync(userId);
                return Ok(transactions);
            }
            catch (Exception ex)
            {
                // Log the exception (you can use a logging framework)
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving transactions for user {userId}: {ex.Message}");
            }
        }
    }
}
