﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OLXShopping.Entities;
using OLXShopping.Repositories;
using System;
using System.Threading.Tasks;

namespace OLXShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IConfiguration _configuration;

        public OrderController(IOrderRepository orderRepository, IConfiguration configuration)
        {
            _orderRepository = orderRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetByIdAsync(Guid id)
        {
            try
            {
                var order = await _orderRepository.GetByIdAsync(id);
                if (order == null)
                {
                    return NotFound();
                }
                return Ok(order);
            }
            catch (Exception ex)
            {
                // Log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the order.");
            }
        }

        [HttpGet, Route("GetAllOrders")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var orders = await _orderRepository.GetAllAsync();
                return Ok(orders);
            }
            catch (Exception ex)
            {
                // Log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the orders.");
            }
        }

        [HttpPost, Route("AddOrder")]
        public async Task<IActionResult> AddAsync([FromBody] Order order)
        {
            try
            {
                order.OrderId = Guid.NewGuid();
                await _orderRepository.AddAsync(order);
              
                return Ok(order);
            }
            catch (Exception ex)
            {
                // Log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while adding the order.");
            }
        }

        [HttpPut, Route("UpdateOrder")]
        public async Task<IActionResult> UpdateAsync( [FromBody] Order order)
        {
            try
            {
               
               
                await _orderRepository.UpdateAsync(order);
                return Ok(order);
            }
            catch (Exception ex)
            {
                // Log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while updating the order.");
            }
        }

        [HttpDelete, Route("DeleteOrder/{id}")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            
                
                await _orderRepository.DeleteAsync(id);
                return Ok(id); // No content indicates successful deletion  
        }
        [HttpGet, Route("GetOrdersBoughtByUser/{userId}")]
        public async Task<IActionResult> GetOrdersBoughtByUserIdAsync(string userId)
        {
            try
            {
                // Fetch the orders bought by the user including item details
                var orders = await _orderRepository.GetOrdersBoughtByUserIdAsync(userId);

                // Check if orders exist
                if (orders == null || !orders.Any())
                {
                    return NotFound($"No orders found for user with ID {userId}");
                }

                // Return the orders directly
                return Ok(new { UserId = userId, OrdersBought = orders });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the orders.");
            }
        }




        [HttpGet, Route("GetOrdersSoldByUser/{userId}")]
        public async Task<IActionResult> GetOrdersSoldByUserIdAsync(string userId)
        {
            try
            {
                var count = await _orderRepository.GetOrdersSoldByUserIdAsync(userId);
                return Ok(new { UserId = userId, OrdersSold = count });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the orders.");
            }
        }
        [HttpGet("GetBy Date-Range")]
        public async Task<IActionResult> GetOrdersByDateRange([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            if (startDate > endDate)
            {
                return BadRequest("Start date cannot be after end date.");
            }

            var orders = await _orderRepository.GetOrdersByDateRange(startDate, endDate);

            if (orders == null || !orders.Any())
            {
                return NotFound("No orders found for the specified date range.");
            }

            return Ok(orders);
        }

    }
}
