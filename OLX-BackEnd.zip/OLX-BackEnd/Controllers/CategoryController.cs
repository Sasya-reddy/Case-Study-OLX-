﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OLXShopping.Entities;
using OLXShopping.Repositories;
using System;
using System.Threading.Tasks;

namespace OLXShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    

    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;
        private IConfiguration _configuration;

        public CategoryController(ICategoryRepository categoryRepository, IConfiguration configuration)
        {
            _categoryRepository = categoryRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetById/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetByIdAsync(string id)
        {
            try
            {
               
                var category = await _categoryRepository.GetByIdAsync(id);
                if (category == null)
                {
                    return NotFound();
                }
                return Ok(category);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the category.");
            }
        }

        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var categories = await _categoryRepository.GetAllAsync();
                return Ok(categories);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the categories.");
            }
        }

        [HttpPost,Route("AddCategory")]
        [Authorize(Roles = "Admin")]

        public async Task<IActionResult> AddAsync([FromBody] Category category)
        {
            try
            {
               
                    //user.UserId = Guid.NewGuid().ToString();
                    category.CategoryId = "C" + new Random().Next(1000, 9999);// Or use your preferred ID generation logic
                
               
                await _categoryRepository.AddAsync(category);
                return Ok(category);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while adding the category.");
            }
        }

        [HttpPut,Route("UpdateCategory")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> EditAsync([FromBody] Category category)
        {
            try
            {
               

                 
                await _categoryRepository.UpdateAsync(category);
                return Ok(category);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while updating the category.");
            }
        }

        [HttpDelete, Route("DeleteCategory/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteAsync(string id)
        {
            try
            {
                

                await _categoryRepository.DeleteAsync(id);
                return Ok(id); // No content indicates successful deletion
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while deleting the categoryid.");
            }
        }
    }
}
