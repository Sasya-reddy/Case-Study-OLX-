﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OLXShopping.Entities;
using OLXShopping.Repositories;

namespace OLXShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        private readonly IAddressRepository _addressRepository;
        private readonly IConfiguration _configuration;
        public AddressController(IAddressRepository addressRepository, IConfiguration configuration)
        {
            _addressRepository = addressRepository;
            _configuration = configuration;
        }
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetByIdAsync(string id)
        {
            try
            {
                var address = await _addressRepository.GetByIdAsync(id);
                if (address == null)
                {
                    return NotFound();
                }
                return Ok(address);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the address.");
            }
        }
        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var addresses = await _addressRepository.GetAllAsync();
                return Ok(addresses);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving the addresses.");
            }
        }

        [HttpPost, Route("AddAddress")]
        public async Task<IActionResult> AddAsync([FromBody] Address address)
        {
            try
            {
               
                    //user.UserId = Guid.NewGuid().ToString();
                    address.AddressId = "A" + new Random().Next(1000, 9999);// Or use your preferred ID generation logic
                

                await _addressRepository.AddAsync(address);
                return Ok(address);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw;
            }
        }
        [HttpPut, Route("UpdateAddress/{id}")]
        public async Task<IActionResult> EditAsync(string id, [FromBody] Address address)
        {
            try
            {
                address.AddressId = id; // Ensure the ID is consistent
                await _addressRepository.UpdateAsync(address);
                return Ok(address);
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while updating the address.");
            }
        }
        [HttpDelete, Route("DeleteAddress/{id}")]
        public async Task<IActionResult> DeleteAsync(string id)
        {
            try
            {
                await _addressRepository.DeleteAsync(id);
                return Ok(id); // Return the ID of the deleted address
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while deleting the address.");
            }
        }
        [HttpGet, Route("GetByBuyerId/{buyerId}")]
        public async Task<IActionResult> GetByBuyerIdAsync(string buyerId)
        {
            try
            {
                var address = await _addressRepository.GetByBuyerIdAsync(buyerId);
                if (address == null)
                {
                    return NotFound();
                }
                return Ok(address);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


    }
}
