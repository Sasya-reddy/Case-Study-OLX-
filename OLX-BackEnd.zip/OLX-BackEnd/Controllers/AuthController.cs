﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using OLXShopping.Models;
using OLXShopping.Repositories;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using OLXShopping.Entities;
using System.Text;

namespace OLXShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;

        public AuthController(IUserRepository userRepository, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("Register")]
        public IActionResult AddUser(User user)
        {
            try
            {            
                    //user.UserId = Guid.NewGuid().ToString();
                    user.UserId = "U" + new Random().Next(1000, 9999);// Or use your preferred ID generation logic
                

                _userRepository.Register(user);
                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost, Route("Validate")]
        [AllowAnonymous]
        public IActionResult ValidUser(Login login)
        {
            try
            {
                AuthResponse authResponse = null;
                var user = _userRepository.ValidUser(login.Email, login.Password);
                if (user != null)
                {
                    authResponse = new AuthResponse()
                    {
                        UserId = user.UserId,
                        Role = user.Role,
                        Token = GetToken(user),
                    };
                }
                return Ok(authResponse);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet, Route("GetAllUsers")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAllUsers()
        {
            try
            {
                var users = _userRepository.GetAllUsers();
                return StatusCode(200, users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut, Route("EditUser")]
        [Authorize(Roles = "Admin")]
        public IActionResult Update([FromBody] User user) // Edit user details
        {
            try
            {
                _userRepository.Update(user);
                return StatusCode(200, user);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete, Route("DeleteUser")]
        [Authorize(Roles = "Admin")]
        public IActionResult Delete([FromQuery] string UserId) // Delete user using id
        {
            try
            {
                _userRepository.Delete(UserId);
                return Ok(); // Empty response
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        private string GetToken(User user)
        {
            try
            {
                var issuer = _configuration["Jwt:Issuer"];
                var audience = _configuration["Jwt:Audience"];
                var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);

                var signingCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha512Signature
                );

                var subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(ClaimTypes.Role, user.Role),
                });

                var expires = DateTime.UtcNow.AddMinutes(10); // Token will expire after 10min
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = subject,
                    Expires = expires,
                    Issuer = issuer,
                    Audience = audience,
                    SigningCredentials = signingCredentials
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var jwtToken = tokenHandler.WriteToken(token);
                return jwtToken;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error generating token: {ex.Message}");
            }
        }
    }
}
