﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace OLXShopping.Entities
{
    [Table("Transactions")]
    public class Transaction
    {
        [Key]
        [Column(TypeName = "uniqueidentifier")]
        public Guid TransactionId { get; set; } = Guid.NewGuid(); // Default value is a new GUID

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; } // Total amount of the transaction

        [Required]
        [Column(TypeName = "datetime")]
        public DateTime TransactionDate { get; set; } // Date of the transaction

        [Required]
        [Column(TypeName = "varchar(50)")]
        public string PaymentMethod { get; set; }

        // Foreign key to User
        [Required]
        public string UserId { get; set; }

        [ForeignKey("UserId")]
        [JsonIgnore]
        public User? User { get; set; } // Relationship with User

        public Guid OrderId { get; set; }

        [ForeignKey("OrderId")]
        [JsonIgnore]
        public Order? Order { get; set; } // Relationship with Order
    }
}
