﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OLXShopping.Entities
{
    [Table("User")]
    public class User
    {
        [Key]
        [Required(ErrorMessage ="Id is Required")]
        [Column(TypeName="varchar")]
        [StringLength(50)]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Username is Required")]
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string UserName { get; set; }

        
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string Email {  get; set; }


        [Required]
        [Column(TypeName = "varchar")]
        [StringLength(255)]
        public string Password {  get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string Role { get; set; }
        
        
    }


}

