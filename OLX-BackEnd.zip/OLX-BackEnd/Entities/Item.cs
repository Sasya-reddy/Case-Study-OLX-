﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OLXShopping.Entities
{
    [Table("Items")]
    public class Item
    {
        [Key]
        [Column(TypeName = "nvarchar(100)")]
        
        public string ItemId { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string Name { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string? ItemImage { get; set; } // Image URL or path

        [Required]
        [Column(TypeName = "datetime")]
        public DateTime PostedDate { get; set; } // Date when the item was posted

        [Required]
        [Column(TypeName = "varchar(max)")]
        public string Description { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string Location { get; set; }


        [ForeignKey("Category")]
        public string CategoryId { get; set; }
        [JsonIgnore]
        public Category? Category { get; set; }

        public string SellerId { get; set; }

        [ForeignKey("SellerId")]
        [JsonIgnore]
        public User? Seller { get; set; }

    }
}
