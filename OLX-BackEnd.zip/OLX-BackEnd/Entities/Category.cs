﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace OLXShopping.Entities
{
    [Table("Category")]
    public class Category
    {
        [Key]
        [Column(TypeName = "varchar(100)")]
        //[RegularExpression("C[0-9]{4,5}", ErrorMessage = "Id allow only 4 to 5 chars")]
        public string CategoryId { get; set; } // Unique identifier for the category

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string CategoryName { get; set; } // Name of the category

       
    }
}
