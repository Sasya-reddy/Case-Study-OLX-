﻿using Microsoft.EntityFrameworkCore;

namespace OLXShopping.Entities
{
    public class OLXAppContext : DbContext
    {
        private readonly IConfiguration obj;

        public OLXAppContext(IConfiguration configuration)
        {
            obj = configuration;
        }
        public DbSet<User> Users {  get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Address> Address { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // optionsBuilder.UseSqlServer("Data Source=DESKTOP-MMAT251\\SQLEXPRESS01;Initial Catalog=Ecomm;Integrated Security=True;Trust Server Certificate=True\r\n");
            optionsBuilder.UseSqlServer(obj.GetConnectionString("OLXAppConnection"));
        }

    }
}
