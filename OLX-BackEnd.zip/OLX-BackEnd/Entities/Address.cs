﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OLXShopping.Entities
{
    public class Address
    {
        [Key]
        [Column(TypeName = "varchar(100)")]
        
        public string AddressId { get; set; }
        public string BuyerId { get; set; }


        [ForeignKey("BuyerId")]
        [JsonIgnore]
        public User? Buyer { get; set; }

        [Required]
        [Column(TypeName = "varchar(200)")]
        public string Street { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string City { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string State { get; set; }

        [Required]
        [Column(TypeName = "varchar(10)")]
        public string PostalCode { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string Country { get; set; }
    }
}

