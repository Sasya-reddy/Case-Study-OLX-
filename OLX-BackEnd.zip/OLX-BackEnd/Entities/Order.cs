﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace OLXShopping.Entities
{
    [Table("Orders")]
    public class Order
    {
        [Key]
        [Column(TypeName = "uniqueidentifier")]
        //public Guid OrderId { get; set; } = Guid.NewGuid();
        public Guid OrderId { get; set; } = Guid.NewGuid();// Default value is a new GUID


        [Required]
        [Column(TypeName = "datetime")]
        public DateTime OrderDate { get; set; } // When the order was placed

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; } // Total amount for the order

        [Required]
        [Column(TypeName = "varchar(50)")]
        public string OrderStatus { get; set; } //pending completed cancelled
       
        public string ItemId { get; set; }
        [ForeignKey("ItemId")]
        [JsonIgnore]
        public Item? Item { get; set; }

        public string BuyerId { get; set; }


        [ForeignKey("BuyerId")]
        [JsonIgnore]
        public User? Buyer { get; set; }

        public string SellerId { get; set; }
        [ForeignKey("SellerId")]
        [JsonIgnore]
        public User? Seller { get; set; } // Relationship with User who is the Buyer




        public string AddressId { get; set; }

        [ForeignKey("AddressId")]
        [JsonIgnore]
        public Address? Address { get; set; }





    }
}
