import { useState } from "react";
import axios from "axios";

const AddAddress = () => {
  const [address, setAddress] = useState({
    addressId: "",
    buyerId: sessionStorage.getItem("userId") || "",
    street: "",
    city: "",
    state: "",
    postalCode: "",
    country: "",
  });

  const handleChange = (e) => {
    setAddress({ ...address, [e.target.name]: e.target.value });
  };

  const saveAddress = (e) => {
    e.preventDefault();

    const token = sessionStorage.getItem("token");

    axios
      .post("http://localhost:5151/api/Address/AddAddress", address, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        console.log(response.data);
        alert("Address added successfully!");
      })
      .catch((error) => console.error("Error adding address: ", error));
  };

  return (
    <div className="container">
      <form onSubmit={saveAddress}>
        <table className="table">
          <tbody>
            <tr>
              <td>Street</td>
              <td>
                <input
                  type="text"
                  name="street"
                  value={address.street}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td>City</td>
              <td>
                <input
                  type="text"
                  name="city"
                  value={address.city}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td>State</td>
              <td>
                <input
                  type="text"
                  name="state"
                  value={address.state}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td>Postal Code</td>
              <td>
                <input
                  type="text"
                  name="postalCode"
                  value={address.postalCode}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td>Country</td>
              <td>
                <input
                  type="text"
                  name="country"
                  value={address.country}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit">Save Address</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default AddAddress;
