import { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./MyOrders.css";

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError("User ID not found. Please log in.");
      return;
    }

    const fetchOrders = async () => {
      try {
        const response = await axios.get(`http://localhost:5151/api/Order/GetOrdersBoughtByUser/${userId}`);
        console.log(response)
        if (response.data && Array.isArray(response.data.ordersBought)) {
          setOrders(response.data.ordersBought);
        } else {
          setOrders([]);
        }
      } catch (error) {
        console.error(error);
        setError("An error occurred while fetching orders.");
      }
    };

    fetchOrders();
  }, []);

  return (
    <>
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>olx</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>

          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>

          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>

      <div className="container mt-5">
        <h2 className="mb-4">My Orders</h2>
        {error && <div className="alert alert-danger" role="alert">{error}</div>}

        {orders.length > 0 ? (
          <div className="list-group">
            {orders.map((order) => (
              <div key={order.orderId} className="list-group-item list-group-item-action">
                <div className="d-flex w-100 justify-content-between">
                  <h5 className="mb-1">Order ID: {order.orderId}</h5>
                  {/* <small>{new Date(order.transactionDate).toLocaleDateString()}</small> */}
                </div>
                <p className="mb-1"><strong>Total Amount:</strong> ${order.totalAmount}</p>
                {/* <p className="mb-1"><strong>Payment Method:</strong> {order.paymentMethod}</p> */}
                {/* Add more order details as needed */}
              </div>
            ))}
          </div>
        ) : (
          <div className="alert alert-info" role="alert">No orders found for this User ID.</div>
        )}
      </div>
    </>
  );
};

export default MyOrders;
