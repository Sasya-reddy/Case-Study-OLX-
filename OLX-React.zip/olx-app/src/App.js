import React from 'react';
import './App.css';
import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import Home from './Home';
import Login from "./Login";
import Register from "./Register";
import CategoryDropdown from './CategoryComponent/GetCategories';
import AddCategory from './CategoryComponent/AddCategory';
import GetItems from './Item Component/GetItems';
import MyItems from './Item Component/MyItems';
import AddItem from './Item Component/AddItems';
import UpdateItem from './Item Component/Update';
import MyOrders from './MyOrders';
import AddOrder from './AddOrder';
import UserDashboard from './User-dasboard';
import AddTransaction from './AddTransaction';
import GetAllUsers from './AllUsers';
import AdminDashboard from './Admin-dashboard';
import GetAllItems from './GetAllItems';


function App() {
  return (
    <BrowserRouter>
        <main>
          <div className="content">
            <Routes>
              <Route index  element={<Home />}  />
              <Route  path="Home" element={<Home />}  />
              <Route path="Login" element={<Login />} /> 
              <Route path="Register" element={<Register />} />
              {/* Admin Dashboard */}
              <Route path="AdminDashboard" element={<AdminDashboard />} />
              <Route path='GetAllUsers' element={<GetAllUsers />} />
              <Route path="GetAllItems" element={<GetAllItems />} />
              <Route path="AddCategory" element={<AddCategory />} />
              
              {/* userdashboard */}
              <Route path="UserDashboard" element={<UserDashboard />} />
              <Route path="Categories" element={<CategoryDropdown />} />
              <Route path="getitems" element={<GetItems />} />
              <Route path="AddItems" element={<AddItem />} />
              <Route path="MyItems" element={<MyItems />} />
              <Route path="/UpdateItem/:itemId" element={<UpdateItem />} />
              <Route path="MyOrders" element={<MyOrders />} />
              <Route path="AddOrder" element={<AddOrder />} />
              <Route path="AddTransaction" element={<AddTransaction />} />
            </Routes>
          </div>
        </main>
     
    </BrowserRouter>
  );
}

export default App;
