import React from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "./Register.css";

const Register = () => {
  const navigate = useNavigate();

  // Validation schema using Yup
  const validationSchema = Yup.object().shape({
    userName: Yup.string().required("Name is required"),
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is required"),
    password: Yup.string()
      .min(6, "Password must be at least 6 characters long")
      .required("Password is required"),
  });

  // Form submission handler
  const handleSubmit = (values, { setSubmitting, setFieldError }) => {
    const user = {
      userId: 'dd',
      userName: values.userName,
      email: values.email,
      password: values.password,
      role: 'User',
    };

    axios
      .post("http://localhost:5151/api/Auth/Register", user)
      .then((res) => {
        console.log(res.data);
        setSubmitting(false);
        setTimeout(() => {
          navigate("/login"); // Navigate to Login after 2 seconds
        }, 2000);
      })
      .catch((err) => {
        console.error(err);
        setFieldError("email", "Registration failed. Please try again.");
        setSubmitting(false);
      });
  };

  return (
    <div className="register-container">
      <div className="register-box">
        <h2>Register</h2>
        <Formik
          initialValues={{ userName: "", email: "", password: "" }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form>
              <div className="form-group">
                <label htmlFor="userName">Name</label>
                <Field
                  type="text"
                  name="userName"
                  className="form-control"
                />
                <ErrorMessage
                  name="userName"
                  component="div"
                  className="error-message"
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email</label>
                <Field
                  type="email"
                  name="email"
                  className="form-control"
                />
                <ErrorMessage
                  name="email"
                  component="div"
                  className="error-message"
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password</label>
                <Field
                  type="password"
                  name="password"
                  className="form-control"
                />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="error-message"
                />
              </div>

              <button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Registering..." : "Register"}
              </button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default Register;
