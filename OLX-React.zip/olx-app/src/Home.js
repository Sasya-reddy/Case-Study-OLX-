import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import the useNavigate hook
import './Home.css';
import './App.css';

const Home = () => {
  const navigate = useNavigate(); // Initialize the navigate function

  const handleGetStarted = () => {
    navigate('/login'); // Navigate to the login page
  };

  return (
    <div className="App">
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>olx</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'>Home</a></li>
            <li><a href='/Login'>Login</a></li>
            <li><a href='/Register'>Register</a></li>
          </ul>
        </nav>
      </header>

      <div className="home-container">
        <h1>Welcome to Scrap Dealer</h1>
        <p>Your one-stop solution for buying and selling scrap materials online. Whether you're looking to get rid of old, unused items or you're in search of affordable scrap materials for your next project, we've got you covered.</p>
        <div className="features">
          <h2>Why Choose Us?</h2>
          <ul>
            <li>✔️ Easy to post your items</li>
            <li>✔️ Quick search for the best deals</li>
            <li>✔️ Safe and secure transactions</li>
            <li>{'\u2714'} Trusted by thousands of users</li>
          </ul>
        </div>

        <div className="call-to-action">
          <p>Ready to start buying or selling? Click below to get started!</p>
          <button onClick={handleGetStarted}> {/* Use the handler */}
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
};

export default Home;
