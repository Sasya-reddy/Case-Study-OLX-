import { Navigate } from "react-router-dom";
import './App.css';
const UserDashboard = () => {
    return(
    <div className="App">
        <header className="App-header">
          <nav className="navbar">
            <div className="logo">
              <h1>olx</h1>
            </div>
            <ul className="nav-links">
            
               <li><a href='/Home'><button>Logout</button></a></li>
            </ul>
            <div className="dropdown">
  <button className="dropbtn">Categories</button>
  <div className="dropdown-content">
    <a href="/Categories">Select Category</a>
  </div>
</div>

<div className="dropdown">
  <button className="dropbtn">My Profile</button>
  <div className="dropdown-content">
    <a href="/MyItems">My Items</a>
    <a href="/MyOrders">My Orders</a>
    {/* <a href="/Update">Update Item</a> */}
    <a href="/MyTransactions">My Transactions</a>
  </div>
</div>

<div className="sell-button">
  <a href="/AddItems">
    <button>+ Sell</button>
  </a>
</div>

          </nav>
        </header>
        </div>
        );
   
  };
  export default UserDashboard;