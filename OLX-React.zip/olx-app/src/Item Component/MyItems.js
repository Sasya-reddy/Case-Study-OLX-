import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./MyItems.css";

const MyItems = () => {
  const [items, setItems] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError("User ID not found. Please log in.");
      return;
    }

    const fetchItems = async () => {
      try {
        const response = await axios.get(`http://localhost:5151/api/Item/GetItemsByUserId/${userId}`);
        console.log(response);
        setItems(response.data); 
      } catch (error) {
        console.error(error);
        setError("An error occurred while fetching items.");
      }
    };

    fetchItems();
  }, []);

  const handleUpdate = (itemId) => {
    navigate(`/UpdateItem/${itemId}`);
  };

  return (
    <>
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>olx</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>

          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>

          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>

      <div className="container">
        <h2>My Items</h2>
        {error && <p className="error-message">{error}</p>}

        <div className="card-container">
          {items.length > 0 ? (
            items.map((item) => (
              <div className="card" key={item.itemId}>
                <div className="card-content">
                  <h3>{item.name}</h3>
                  <p><strong>Description:</strong> {item.description}</p>
                  <p><strong>Price:</strong> {item.price}</p>
                  <p><strong>Location:</strong> {item.location}</p>
                  <p><strong>Posted Date:</strong> {new Date(item.postedDate).toLocaleDateString()}</p>
                  <button onClick={() => handleUpdate(item.itemId)}>Update</button>
                </div>
              </div>
            ))
          ) : (
            <p>No items found for this User ID.</p>
          )}
        </div>
      </div>
    </>
  );
};

export default MyItems;
