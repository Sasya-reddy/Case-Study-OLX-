import { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
// import './UpdateItem.css'; // Ensure this path is correct

const UpdateItem = () => {
  const { itemId } = useParams(); // Get itemId from URL parameters
  const [item, SetItem] = useState({
    name: "",
    itemImage: "",
    postedDate: new Date().toISOString(),
    description: "",
    price: 0,
    location: "",
  });
  const [err, setError] = useState("");

  useEffect(() => {
    if (itemId) {
      axios
        .get(`http://localhost:5151/api/Item/GetById/${itemId}`)
        .then((res) => {
          SetItem(res.data); // Set item details to state
        })
        .catch((err) => {
          console.error(err);
          setError("An error occurred while fetching item details.");
        });
    }
  }, [itemId]);

  const save = (e) => {
    e.preventDefault();
    axios
      .put("http://localhost:5151/api/Item/UpdateItem", item)
      .then((res) => {
        console.log(res.data);
        // Optionally redirect or show a success message here
      })
      .catch((err) => {
        console.error(err);
        setError("An error occurred while updating the item.");
      });
  };

  const removeItem = (e) => {
    e.preventDefault();
    axios
      .delete(`http://localhost:5151/api/Item/DeleteItem/${itemId}`)
      .then((res) => {
        console.log(res.data);
        // Optionally redirect or show a success message here
      })
      .catch((err) => {
        console.error(err);
        setError("An error occurred while deleting the item.");
      });
  };

  return (
    <div>
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>olx</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>
          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              {/* <a href="/Update">Update Item</a> */}
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>
          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>
      <div className="container">
        <form onSubmit={save}>
          <table className="table">
            <tbody>
              <tr>
                <td>Name</td>
                <td>
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        name: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Item Image</td>
                <td>
                  <input
                    type="text"
                    value={item.itemImage}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        itemImage: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Posted Date</td>
                <td>
                  <input
                    type="text"
                    value={item.postedDate}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        postedDate: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Description</td>
                <td>
                  <input
                    type="text"
                    value={item.description}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        description: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Price</td>
                <td>
                  <input
                    type="text"
                    value={item.price}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        price: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Location</td>
                <td>
                  <input
                    type="text"
                    value={item.location}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        location: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td colSpan={2}>
                  <button type="submit">Update</button>
                  <button onClick={removeItem}>Delete</button>
                </td>
              </tr>
              {err && (
                <tr>
                  <td colSpan={2}>
                    <p style={{ color: "red" }}>{err}</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </form>
      </div>
    </div>
  );
};

export default UpdateItem;
