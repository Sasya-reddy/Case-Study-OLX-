import { useState, useEffect } from "react";
import axios from "axios";
import './AddItems.css'; // Import the CSS file for styling

const AddItem = () => {
  const [item, SetItem] = useState({
    itemId: "dddd",
    name: "",
    itemImage: "",
    postedDate: new Date().toISOString(),
    description: "",
    price: 0,
    location: "",
    categoryId: "", // Initially empty
    sellerId: sessionStorage.getItem('userId'),
  });

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    // Fetch all categories
    axios
      .get("http://localhost:5151/api/Category/GetAll")
      .then((response) => {
        setCategories(response.data); // Set the fetched categories to the state
      })
      .catch((error) => console.log(error));
  }, []);

  const handleCategoryChange = (e) => {
    SetItem((prevObj) => ({
      ...prevObj,
      categoryId: e.target.value, // Update categoryId based on the selection
    }));
  };

  const save = (e) => {
    e.preventDefault(); // Prevent form from submitting the traditional way
    console.log(item);
    axios
      .post("http://localhost:5151/api/Item/AddItems", item)
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      {/* Header */}
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>olx</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>

          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>

          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <div className="container">
        <form onSubmit={save}>
          <table className="table">
            <tbody>
              <tr>
                <td>Name</td>
                <td>
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        name: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Item Image</td>
                <td>
                  <input
                    type="text"
                    value={item.itemImage}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        itemImage: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Posted Date</td>
                <td>
                  <input
                    type="text"
                    value={item.postedDate}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        postedDate: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Description</td>
                <td>
                  <input
                    type="text"
                    value={item.description}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        description: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Price</td>
                <td>
                  <input
                    type="text"
                    value={item.price}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        price: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Location</td>
                <td>
                  <input
                    type="text"
                    value={item.location}
                    onChange={(e) =>
                      SetItem((prevObj) => ({
                        ...prevObj,
                        location: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Category</td>
                <td>
                  <select
                    className="form-control"
                    value={item.categoryId}
                    onChange={handleCategoryChange}
                  >
                    <option value="" disabled>
                      -- Select a Category --
                    </option>
                    {categories.map((category) => (
                      <option key={category.categoryId} value={category.categoryId}>
                        {category.categoryName}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
              <tr>
                <td colSpan={2}>
                  <button type="submit">Save</button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
  );
};

export default AddItem;
