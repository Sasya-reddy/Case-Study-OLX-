import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./GetItems.css"; // Import the CSS file for styling
import img1 from '../images/OLX Lap.jpg'; // Sample image, replace with dynamic images if available

const GetItems = () => {
  const [items, setItems] = useState([]);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [categoryName, setCategoryName] = useState("");
  const [location, setLocation] = useState("");
  const [itemName, setItemName] = useState("");
  const navigate = useNavigate(); // Define navigate

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = () => {
    axios
      .get("http://localhost:5151/api/Item/GetItemsByFilter", {
        params: {
          minPrice: minPrice || null,
          maxPrice: maxPrice || null,
          categoryName: categoryName || null,
          location: location || null,
          itemName: itemName || null,
        },
      })
      .then((response) => {
        console.log("API response:", response.data); // Ensure data is correct
        setItems(response.data); // Update items state with fetched data

        // Optional: Store prices in sessionStorage for debugging purposes
        response.data.forEach((item, index) => {
          sessionStorage.setItem(`ItemPrice_${index}`, item.price); // Use a unique key for each price
        });

        console.log('Prices stored in sessionStorage:', response.data.map((item, index) => `ItemPrice_${index}: ${item.price}`));
      })
      .catch(error => {
        console.log('Error fetching items:', error);
      });
  };

  const handleFilterSubmit = (e) => {
    e.preventDefault();
    fetchItems(); // Fetch filtered items
  };

  const handleOrderClick = (itemId) => {
    navigate(`/addorder?itemId=${itemId}`);
  };

  return (
    <div className="App">
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>OLX</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>

          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>

          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>

      <div className="container">
        <form onSubmit={handleFilterSubmit} className="filter-form">
          <div className="form-group">
            <label>Min Price: </label>
            <input
              type="number"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Max Price: </label>
            <input
              type="number"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Category Name: </label>
            <input
              type="text"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Location: </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Item Name: </label>
            <input
              type="text"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
            />
          </div>
          <button type="submit" className="filter-btn">
            Apply Filter
          </button>
        </form>

        <div className="card-container">
          {items.length > 0 ? (
            items.map((i) => (
              <div className="card" key={i.itemId}>
                <img src={img1} alt={i.name} className="card-image" />
                <div className="card-content">
                  <h3>{i.name}</h3>
                  <p><strong>Description:</strong> {i.description}</p>
                  <p><strong>Price:</strong> {i.price}</p>
                  <p><strong>Seller ID:</strong> {i.sellerId}</p>
                  <p><strong>Location:</strong> {i.location}</p>
                  <p><strong>Posted:</strong> {i.postedDate}</p>
                  <button
                    onClick={() => handleOrderClick(i.itemId)}
                    className="add-order-btn"
                  >
                    Add Order
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p>No items found. Please adjust your filters.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default GetItems;
