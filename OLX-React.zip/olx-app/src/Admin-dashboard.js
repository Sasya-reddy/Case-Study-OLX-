import React from "react";
import { Link } from "react-router-dom";
// import './App.css'; // Import your custom CSS file

const AdminDashboard = () => {
    return (
        <div className="App">
            <header className="App-header">
                <nav className="navbar">
                    <div className="logo">
                        <h1>OLX Admin</h1>
                    </div>
                    <ul className="nav-links">
                        <li><Link to="/Home"><button>Logout</button></Link></li>
                    </ul>

                    <div className="dropdown">
                        <button className="dropbtn">Admin Actions</button>
                        <div className="dropdown-content">
                            <Link to="/GetAllUsers">GetAllUsers</Link>
                            {/* <Link to="/GetItems">GetItems</Link> */}
                            <Link to="/GetAllItems">GetAllItems</Link>
                            <a href="/AddCategory">AddCategory</a>
                            {/* <Link to="/CategoryDropdown">Categories</Link> */}
                        </div>
                    </div>
                    <div className="sell-button">
                        <Link to="/AddItems">
                            <button>+ Sell</button>
                        </Link>
                    </div>
                </nav>
            </header>

            {/* Admin Dashboard Content */}
            <main>
                <h2>Welcome to the Admin Dashboard</h2>
                {/* Add more admin-specific content here */}
            </main>
        </div>
    );
};

export default AdminDashboard;
