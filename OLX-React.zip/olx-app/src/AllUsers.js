import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AllUsers.css';


const GetAllUsers = () => {
    const [users, setUsers] = useState([]);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const token = sessionStorage.getItem('token'); // Using sessionStorage instead of localStorage

                if (!token) {
                    setError('Unauthorized: No token found. Please log in.');
                    return;
                }

                const response = await axios.get('http://localhost:5151/api/Auth/GetAllUsers', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                setUsers(response.data);
            } catch (err) {
                if (err.response && err.response.status === 401) {
                    setError('Unauthorized: Invalid or expired token. Please log in again.');
                } else {
                    setError('Failed to fetch users. Please try again later.');
                }
                console.error(err);
            }
        };

        fetchUsers();
    }, []);

    const deleteUser = async (userId) => {
        try {
            const token = sessionStorage.getItem('token'); // Get the token from sessionStorage
    
            if (!token) {
                setError('Unauthorized: No token found. Please log in.');
                return;
            }
    
            // Updated to match the API query parameter `UserId`
            await axios.delete(`http://localhost:5151/api/Auth/DeleteUser?UserId=${encodeURIComponent(userId)}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
    
            setSuccess('User deleted successfully');
            setUsers(users.filter(user => user.userId !== userId));
        } catch (err) {
            if (err.response && err.response.status === 401) {
                setError('Unauthorized: Invalid or expired token. Please log in again.');
            } else if (err.response && err.response.status === 400) {
                setError('Bad Request: Please check the user ID or request format.');
            } else {
                setError('Failed to delete user. Please try again later.');
            }
            console.error(err);
        }
    };
    
    return (
        <div className="container mt-5 get-all-users-container">
            <h2 className="mb-4 text-center text-uppercase">All Users</h2>
            {error && <div className="alert alert-danger fade show">{error}</div>}
            {success && <div className="alert alert-success fade show">{success}</div>}
            {users.length > 0 ? (
                <div className="table-responsive">
                    <table className="table table-hover table-bordered">
                        <thead className="thead-custom">
                            <tr>
                                <th>UserID</th>
                                <th>UserName</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.userId}>
                                    <td>{user.userId}</td>
                                    <td>{user.userName}</td>
                                    <td>{user.email}</td>
                                    <td>{user.role}</td>
                                    <td>
                                        <button 
                                            onClick={() => deleteUser(user.userId)} 
                                            className="btn btn-danger btn-sm btn-custom"
                                        >
                                            <i className="bi bi-trash"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-center">No users found.</p>
            )}
        </div>
    );
};

export default GetAllUsers;
