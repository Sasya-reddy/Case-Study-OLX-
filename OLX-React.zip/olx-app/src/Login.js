import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "./Login.css"; 
// Import your CSS file

const Login = () => {
  const navigate = useNavigate();

  // Validation schema using Yup
  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is required"),
    password: Yup.string()
      .min(6, "Password must be at least 6 characters long")
      .required("Password is required"),
  });

  // Form submission handler
  const handleSubmit = (values, { setSubmitting, setFieldError }) => {
    let user = { email: values.email, password: values.password };

    axios
      .post("http://localhost:5151/api/Auth/Validate", user)
      .then((response) => {
        if (response.status === 204) {
          setFieldError("email", "Invalid User Credentials");
        } else {
          let user = response.data;
          console.log(user)
          sessionStorage.setItem("token", user.token);
          sessionStorage.setItem("userId",user.userId);

          if (user.role === "Admin") {
            navigate("/AdminDashboard");
        }
         else if (user.role === "User") {
            navigate("/UserDashboard");
          }
        }
        setSubmitting(false);
      })
      .catch((error) => {
        setFieldError("email", "Server Error: Unable to login. Please try again later.");
        setSubmitting(false);
      });
  };

  return (
    <div className="login-container">
      <Formik
        initialValues={{ email: "", password: "" }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ isSubmitting }) => (
          <Form className="login-form">
          
            <h2>Login</h2>
            <div className="form-group">
              <label>Email</label>
              <Field
                type="text"
                name="email"
                className="form-control"
              />
              <ErrorMessage
                name="email"
                component="div"
                className="error-message"
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <Field
                type="password"
                name="password"
                className="form-control"
              />
              <ErrorMessage
                name="password"
                component="div"
                className="error-message"
              />
            </div>
            <button
              type="submit"
              className="login-button"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Logging in..." : "Login"}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Login;
