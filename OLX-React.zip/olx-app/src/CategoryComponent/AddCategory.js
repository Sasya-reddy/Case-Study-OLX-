import { useState } from "react";
import axios from "axios";

const AddCategory = () => {
  const [category, setCategory] = useState({
    categoryName: "", // Only sending categoryName
  });
  
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const save = (e) => {
    e.preventDefault();

    // Ensure categoryName is not empty
    if (!category.categoryName) {
      setError("Category name cannot be empty");
      return;
    }

    // Retrieve token from sessionStorage
    const token = sessionStorage.getItem("token");

    axios
      .post(
        "http://localhost:5151/api/Category/AddCategory", 
        { categoryName: category.categoryName }, // Sending only categoryName
        {
          headers: {
            Authorization: `Bearer ${token}`, // Add the token to the request header
            'Content-Type': 'application/json', // Ensure JSON content type is specified
          },
        }
      )
      .then((res) => {
        console.log(res.data);
        setSuccess("Category added successfully!");
        setError(""); // Clear any previous errors
        setCategory({ categoryName: "" }); // Reset input field
      })
      .catch((err) => {
        console.error(err);
        setError("Failed to add category. Please check input and try again.");
      });
  };

  return (
    <div className="container">
      <h2 className="mt-4">Add New Category</h2>

      {/* Show error or success messages */}
      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      <form onSubmit={save}>
        <table className="table">
          <tbody>
            <tr>
              <td>Category Name</td>
              <td>
                <input
                  type="text"
                  value={category.categoryName}
                  onChange={(e) =>
                    setCategory((prevObj) => ({
                      ...prevObj,
                      categoryName: e.target.value, // Update categoryName in state
                    }))
                  }
                  className="form-control"
                  placeholder="Enter category name"
                  required
                />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit" className="btn btn-primary">
                  Save Category
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default AddCategory;
