import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
// import './Home.css'; // Include your CSS file

const CategoryDropdown = () => {
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch all categories
    axios
      .get("http://localhost:5151/api/Category/GetAll")
      .then((response) => {
        console.log(response.data);
        setCategories(response.data); // Set the fetched categories to the state
      })
      .catch((error) => console.log(error));
  }, []);

  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
  };

  const handleCategorySelect = () => {
    if (selectedCategory) {
      // Navigate to GetItems component and pass the selected category as a parameter
      navigate(`/GetItems?categoryName=${selectedCategory}`);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>OLX</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>

          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>

          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>

      <div className="container">
        <h2>Select Category</h2>
        <div className="form-group">
          <select
            className="form-control"
            value={selectedCategory}
            onChange={handleCategoryChange}
          >
            <option value="" disabled>
              -- Select a Category --
            </option>
            {categories.map((category) => (
              <option key={category.categoryId} value={category.categoryName}>
                {category.categoryName}
              </option>
            ))}
          </select>
        </div>
        <button className="btn btn-primary mt-2" onClick={handleCategorySelect}>
          Go to Items
        </button>
      </div>
    </div>
  );
};

export default CategoryDropdown;
