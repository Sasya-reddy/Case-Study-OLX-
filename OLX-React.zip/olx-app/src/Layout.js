import React, { useEffect } from "react";
import { Link, Outlet, Navigate } from "react-router-dom";
import './App.css';

const Layout = () => {
  const token = sessionStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      // Redirect to login if no token is found
      return <Navigate to="/login" />;
    }
  }, [token]);

  if (!token) {
    return null; // Render nothing until the redirection is completed
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>OLX</h1>
      </header>
      <nav className="navbar">
        <ul>
          <li>
            <Link to="/Home">Home</Link>
          </li>
          <li>
            <Link to="/Categories">Categories</Link>
          </li>
          <li>
            <Link to="/MyItems">My Items</Link>
          </li>
          <li>
            <Link to="/MyOrders">My Orders</Link>
          </li>
          <li>
            <Link to="/AddItems">+ Sell</Link>
          </li>
          <li>
            <Link to="/login">
              <button>Logout</button>
            </Link>
          </li>
        </ul>
      </nav>
      <main>
        <Outlet />
        {/* Outlet is like a placeholder and all requested routes are rendered to Outlet element */}
      </main>
      <footer>
        <h2>
          All Rights Reserved @<a href="#">AbcSchool</a> 2024-25
        </h2>
      </footer>
    </div>
  );
};

export default Layout;
