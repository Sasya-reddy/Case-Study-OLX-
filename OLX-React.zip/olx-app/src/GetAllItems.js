import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import './GetAllItems.css';
const GetAllItems = () => {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:5151/api/Item/GetAllItems", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log(response.data);
        setItems(response.data); // Adding response data to items
      })
      .catch((error) => console.log(error));
  }, []);

  const removeItem = (itemId) => {
    axios
      .delete(`http://localhost:5151/api/Item/DeleteItem?id=${itemId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        setItems(items.filter(item => item.itemId !== itemId)); // Remove item from local state
      })
      .catch((error) => console.log(error));
  };

  const updateItem = (itemId) => {
    sessionStorage.setItem("ItemId", itemId);
    navigate("/admin-dashboard/update");
  };

  return (
    <div className="container">
       <h2 className="mb-4 text-center text-uppercase">All Items</h2>
      <form>
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            
            <tr>
              <td>Id</td>
              <td>Name</td>
              <td>Price</td>
              <td>Location</td>
              <td>Posted Date</td>
              <td>Actions</td>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.itemId}>
                <td>{item.itemId}</td>
                <td>{item.name}</td>
                <td>{item.price}</td>
                {/* <td>{item.stock}</td> */}
                <td>{item.location}</td>
                <td>{new Date(item.postedDate).toLocaleDateString()}</td>
                <td>
                  <button
                    onClick={() => removeItem(item.itemId)}
                    className="btn btn-danger btn-sm"
                  >
                    Delete
                  </button>
                  {/* <button
                    onClick={() => updateItem(item.itemId)}
                    className="btn btn-primary btn-sm"
                  >
                    Update
                  </button> */}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default GetAllItems;
