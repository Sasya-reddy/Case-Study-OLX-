import { useState, useEffect } from "react";
import axios from "axios";
import { useSearchParams, useNavigate } from "react-router-dom";

const AddTransaction = () => {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get("orderId");
  const totalAmount = searchParams.get("totalAmount");
  const navigate = useNavigate(); 

  const [transaction, setTransaction] = useState({
    amount: totalAmount || 0,
    transactionDate: new Date(),
    paymentMethod: "",
    userId: sessionStorage.getItem("userId") || "",
    orderId: orderId || "",
  });

  useEffect(() => {
    if (orderId) {
      axios
        .get(`http://localhost:5151/api/Order/GetById/${orderId}`)
        .then((response) => {
          const { totalAmount } = response.data;
          setTransaction((prevTransaction) => ({
            ...prevTransaction,
            amount: totalAmount,
          }));
        })
        .catch((error) =>
          console.log("Error fetching order details:", error)
        );
    }
  }, [orderId]);

  const saveTransaction = (e) => {
    e.preventDefault();

    const token = sessionStorage.getItem("token");
    axios
      .post("http://localhost:5151/api/Transaction/AddTransaction", transaction, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        console.log(res.data);
        alert("Transaction saved successfully!");
        navigate("/UserDashboard");
      })
      .catch((err) => {
        console.log("Error saving transaction:", err);
        alert("Failed to save transaction. Please try again.");
      });
  };

  return (
    <>
      <header className="App-header">
        <nav className="navbar">
          <div className="logo">
            <h1>olx</h1>
          </div>
          <ul className="nav-links">
            <li><a href='/Home'><button>Logout</button></a></li>
          </ul>
          <div className="dropdown">
            <button className="dropbtn">Categories</button>
            <div className="dropdown-content">
              <a href="/Categories">Select Category</a>
            </div>
          </div>

          <div className="dropdown">
            <button className="dropbtn">My Profile</button>
            <div className="dropdown-content">
              <a href="/MyItems">My Items</a>
              <a href="/MyOrders">My Orders</a>
              <a href="/MyTransactions">My Transactions</a>
            </div>
          </div>

          <div className="sell-button">
            <a href="/AddItems">
              <button>+ Sell</button>
            </a>
          </div>
        </nav>
      </header>

      <div className="container">
        <form onSubmit={saveTransaction}>
          <table className="table">
            <tbody>
              <tr>
                <td>Transaction Date</td>
                <td>
                  <input
                    type="datetime-local"
                    value={transaction.transactionDate}
                    onChange={(e) =>
                      setTransaction((prevTransaction) => ({
                        ...prevTransaction,
                        transactionDate: e.target.value,
                      }))
                    }
                  />
                </td>
              </tr>
              <tr>
                <td>Amount</td>
                <td>
                  <input
                    type="number"
                    value={transaction.amount}
                    readOnly
                  />
                </td>
              </tr>
              <tr>
                <td>Payment Method</td>
                <td>
                  <select
                    value={transaction.paymentMethod}
                    onChange={(e) =>
                      setTransaction((prevTransaction) => ({
                        ...prevTransaction,
                        paymentMethod: e.target.value,
                      }))
                    }
                  >
                    <option value="">Select Payment Method</option>
                    <option value="COD">Cash on Delivery</option>
                    <option value="Debit">Debit</option>
                    <option value="Credit">Credit</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td colSpan={2}>
                  <button type="submit">Complete Transaction</button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    </>
  );
};

export default AddTransaction;
